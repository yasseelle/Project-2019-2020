<?php
/*
Plugin Name: WPLMS Demo3 Sample Data
Plugin URI: http://www.vibethemes.com
Description: Install WPLMS Demo 3 in your site ( http://themes.vibethemes.com/wplms/skins/demo3 )
Author: VibeThemes
Version: 1.0
Author URI: http://www.vibethemes.com
Text Domain: wplms-demo3
*/

if ( ! defined( 'ABSPATH' ) ) exit;

class WPLMS_Demo3{

    public static $instance;
    
    public static function init(){

        if ( is_null( self::$instance ) )
            self::$instance = new WPLMS_Demo3();

        return self::$instance;
    }

    private function __construct(){
    	add_filter('wplms_required_plugins',array($this,'required_plugins'));
    	add_filter('wplms_setup_import_file_path',array($this,'import_file_path'),10,2);
    	add_filter('wplms_data_import_url',array($this,'import_url'));

    	add_filter('wplms_setup_options_panel',array($this,'options'));

    	add_action('init',array($this,'sidebars'));
    	add_action('wplms_after_sample_data_import',array($this,'wplms_customizer_options'),30);
    	add_filter('wplms_setup_layerslider_file',array($this,'stop_layerslider'));
    	add_action('wplms_after_sample_data_import',array($this,'import_revslider'),99);

    	add_filter('wplms_setup_sidebars_file',array($this,'set_sidebars'));
    	add_filter('wplms_setup_widgets_file',array($this,'set_widgets'));
    	add_filter('wplms_setup_plugins',array($this,'setup_plugins'));
		
		add_filter('wplms_setup_bp_pages',array($this,'pages'));
		//add_action('init',array($this,'sidebars_widgets'));
    }

    function pages($pages){
    	$pages['buddydrive'] = 'buddydrive';
    	return $pages;
    }
    function sidebars(){
    	register_sidebar( array(
          	'name' => 'Megamenu',
          	'id' => 'Megamenu',
          	'before_widget' => '<div class="widget"><div class="inside">',
              'after_widget' => '</div></div>',
              'before_title' => '<h4 class="widgettitle"><span>',
              'after_title' => '</span></h4>',
            'description'   => __('This is the MegaMenu sidebar','vibe')
        ));
    }

    function setup_plugins($flag){

    	if(is_plugin_active('revslider/revslider.php') && is_plugin_active('wplms-front-end/wplms-front-end.php') && is_plugin_active('woocommerce/woocommerce.php')){ 
			return false;
		}else{
			return true;
		}
    	return $flag;
    }

    function required_plugins($plugins){
    	unset($plugins[5]);
    	return $plugins;
    }

    function stop_layerslider($file){
    	return '';
    }

    function set_sidebars($file){
    	return plugin_dir_path(__FILE__)."data/sidebars.txt";
    }

    function set_widgets($file){
    	return plugin_dir_path(__FILE__)."data/widgets.txt";
    }

    function import_revslider(){

		$slider_array = array(plugin_dir_path(__FILE__)."data/highlight-showcase4.zip");
		$slider = new RevSlider();
		 
		foreach($slider_array as $filepath){
			$slider->importSliderFromPost(true,true,$filepath);  
		}
    }

	function import_file_path($file_path,$file){
	    $file_path = plugin_dir_path(__FILE__).'data/demo3.xml';
	    return $file_path;
	}

	function import_url(){
	    return plugin_dir_url(__FILE__).'data/uploads/';
	}

	// Options panel
	function options($panel){
		//Extra options for options panel
		$panel['logo'] = plugin_dir_url( __FILE__ ).'data/uploads/logo_black.png';
		$panel['alt_logo'] = plugin_dir_url( __FILE__ ).'data/uploads/logo_black.png';
		$panel['social_icons'] = array('social'=>array('facebook','twitter','dribbble'),'url'=>array('#','#','#'));
		$panel['google_fonts'] = array('Lato-300-latin','Lato-regular-latin','Lato-700-latin','Roboto-regular-latin','Varela-regular-latin','Varela Round-regular-latin');
		return $panel;
	}

	// Setup  Customizer 
	function wplms_customizer_options(){ 
	    $customizer_file = plugin_dir_path(__FILE__).'data/customiser.txt';
	    if(file_exists($customizer_file)){
	        $myfile = fopen($customizer_file , "r") or die("Unable to open file!".$customizer_file );
	        while(!feof($myfile)) {
	            $string = fgets($myfile);
	        }
	        fclose($myfile);
	        $code = base64_decode(trim($string)); 
	        if(is_string($code)){
	            $code = unserialize($code);
	            if(is_array($code)){
	                update_option('vibe_customizer',$code);
	            }
	        }
	    }
	    
	    // Setup Menus
		$wplms_menus = array(
			'top-menu'=>1,
			'main-menu'=>'main-menu',
			'mobile-menu'=>'footer-links',
			'footer-menu'=>'footer-links',
		);
		// End HomePage setup
		
		//Set Menus to Locations
		$vibe_menus  = wp_get_nav_menus();
		if(!empty($vibe_menus) && !empty($wplms_menus)){ // Check if menus are imported
			//Grab Menu values
			global $wpdb;
			foreach($wplms_menus as $key=>$menu_item){
				$term_id = $wpdb->get_var( $wpdb->prepare( "SELECT term_id FROM {$wpdb->terms} WHERE slug = %s LIMIT 1;", "{$menu_item}" ) );	
				if(isset($term_id) && is_numeric($term_id)){
					$wplms_menus[$key]=$term_id;
				}else{
					unset($wplms_menus[$key]);
				}
			}
			//update the theme
			set_theme_mod( 'nav_menu_locations', $wplms_menus);
			update_post_meta(2185,'_menu_item_sidebar','Megamenu');
			update_post_meta(2185,'_menu_item_columns','4');
		}
		//End Menu setup
	}

	function sidebars_widgets(){

		$sidebars_file = plugin_dir_path(__FILE__)."data/sidebars.txt";

		if(file_exists($sidebars_file)){
			$myfile = fopen($sidebars_file , "r") or die("Unable to open file!".$sidebars_file );
			while(!feof($myfile)) {
				$string = fgets($myfile);
			}
			fclose($myfile);
		    $code = base64_decode(trim($string)); 
		    if(is_string($code)){
		        $code = unserialize($code);
		        if(is_array($code)){
		        	update_option('sidebars_widgets',$code);
		        }
		    }
		}
		$widgets_file = plugin_dir_path(__FILE__)."data/widgets.txt";
		if(file_exists($widgets_file)){
			$myfile = fopen($widgets_file , "r") or die("Unable to open file!".$widgets_file );
			while(!feof($myfile)) {
				$string = fgets($myfile);
			}
			fclose($myfile);
	        $code = base64_decode(trim($string)); 
	        if(is_string($code)){
	            $code = unserialize($code);
	            if(is_array($code)){
	            	foreach($code as $key=>$option){
	            		update_option($key,$option);
	            	}
	            }
	        }
		}
	}
}

WPLMS_Demo3::init();


