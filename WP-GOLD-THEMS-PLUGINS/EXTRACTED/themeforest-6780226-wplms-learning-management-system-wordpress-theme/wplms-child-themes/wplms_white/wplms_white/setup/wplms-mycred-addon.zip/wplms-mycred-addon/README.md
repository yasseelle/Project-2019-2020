wplms-mycred-addon
==================

WPLMS MyCred add on Plugin. This plugin provides integration between MyCred and WPLMS Learning Management system for WordPress.
